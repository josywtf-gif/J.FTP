package com.josy.jftp;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Обновление из GitHub Releases: проверка последнего релиза (тег v<номер сборки>),
 * скачивание APK внутри приложения с прогрессом и установка поверх текущей версии.
 * Цвета берутся из текущей темы (Theme) при каждом показе диалога.
 */
public class Updater {
    private static final String REPO = "josywtf-gif/J.FTP";
    private static final int MAX_W_DP = 420;   // максимальная ширина диалога
    private static final int MARGIN_DP = 16;   // отступ от краёв экрана

    private int BG, ACCENT, SURFACE_ALT, DIVIDER, TXT, TXT2, ON_ACCENT, RIPPLE;

    private final Activity a;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean cancel;
    private Dialog infoDialog;
    public boolean installPending;

    public Updater(Activity activity) {
        this.a = activity;
        loadColors();
    }

    /** Перечитывает цвета из активной темы. */
    private void loadColors() {
        Theme.init(a);
        BG = Theme.surface(a);
        ACCENT = Theme.accent(a);
        SURFACE_ALT = Theme.surfaceAlt(a);
        DIVIDER = Theme.divider(a);
        TXT = Theme.text(a);
        TXT2 = Theme.text2(a);
        ON_ACCENT = Theme.onAccent(a);
        RIPPLE = Theme.ripple(a);
    }

    // ---------- версия ----------
    public String versionName() {
        return BuildConfig.VERSION_NAME;
    }

    private String lastUpdate() {
        try {
            long t = a.getPackageManager().getPackageInfo(a.getPackageName(), 0).lastUpdateTime;
            return DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale.getDefault())
                    .format(new Date(t));
        } catch (Exception e) { return "—"; }
    }

    private static int build(String v) {
        if (v == null) return 0;
        v = v.replaceFirst("^[vV]", "");
        int dot = v.indexOf('.');
        if (dot >= 0) v = v.substring(dot + 1);
        try { return Integer.parseInt(v.trim()); } catch (Exception e) { return 0; }
    }

    // ---------- стартовое окно ----------
    public void showStartupInfo() {
        if (a.isFinishing()) return;
        loadColors();
        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable g = new GradientDrawable();
        g.setColor(SURFACE_ALT);
        g.setCornerRadius(dp(12));
        g.setStroke(dp(1), DIVIDER);
        card.setBackground(g);
        card.addView(infoRow("Версия", versionName(), false));
        card.addView(infoRow("Обновлено", lastUpdate(), true));

        LinearLayout wrap = new LinearLayout(a);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(16), 0, 0);
        wrap.addView(card, new LinearLayout.LayoutParams(-1, -2));

        infoDialog = dialog("J.FTP", null, wrap,
                new String[]{"Проверить обновления", "Закрыть"},
                new Runnable[]{this::check, () -> { }}, null);
        infoDialog.show();
    }

    public void dismissInfo() {
        try { if (infoDialog != null && infoDialog.isShowing()) infoDialog.dismiss(); }
        catch (Exception ignored) { }
        infoDialog = null;
    }

    private View infoRow(String label, String value, boolean topGap) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.VERTICAL);
        if (topGap) r.setPadding(0, dp(16), 0, 0);
        TextView l = new TextView(a);
        l.setText(label);
        l.setTextSize(14);
        l.setTextColor(TXT2);
        TextView v = new TextView(a);
        v.setText(value);
        v.setTextSize(16);
        v.setTextColor(TXT);
        v.setPadding(0, dp(4), 0, 0);
        r.addView(l);
        r.addView(v);
        return r;
    }

    // ---------- проверка ----------
    public void check() {
        toast("Проверка обновлений…");
        final int cur = build(versionName());
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection)
                        new URL("https://api.github.com/repos/" + REPO + "/releases/latest").openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(10000);
                c.setRequestProperty("Accept", "application/vnd.github+json");
                JSONObject j = new JSONObject(readAll(c.getInputStream()));
                final int remote = build(j.optString("tag_name", ""));
                String url = null;
                JSONArray assets = j.optJSONArray("assets");
                if (assets != null) for (int i = 0; i < assets.length(); i++) {
                    JSONObject o = assets.getJSONObject(i);
                    if (o.optString("name").endsWith(".apk")) {
                        url = o.optString("browser_download_url", null);
                        break;
                    }
                }
                final String apk = url;
                ui.post(() -> {
                    if (a.isFinishing()) return;
                    if (remote > cur) {
                        dialog("Доступно обновление", "Версия 1." + remote + " (у вас 1." + cur + ")", null,
                                new String[]{"Скачать", "Позже"},
                                new Runnable[]{() -> startDownload(apk), () -> { }}, null).show();
                    } else toast("Установлена последняя версия");
                });
            } catch (Throwable t) {
                ui.post(() -> toast("Не удалось проверить обновления"));
            }
        }).start();
    }

    // ---------- скачивание ----------
    private File dir() { return new File(a.getCacheDir(), "updates"); }

    public void cleanUpdates() {
        try {
            File[] fs = dir().listFiles();
            if (fs != null) for (File f : fs) f.delete();
        } catch (Exception ignored) { }
    }

    private void startDownload(String url) {
        if (url == null || !url.toLowerCase().endsWith(".apk")) { toast("В релизе нет APK-файла"); return; }
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            askInstallPermission();
            return;
        }
        loadColors();
        cleanUpdates();
        dir().mkdirs();
        final File f = new File(dir(), "update.apk");
        cancel = false;

        final TextView pct = new TextView(a);
        pct.setText("Загрузка обновления... 0%");
        pct.setTextSize(16);
        pct.setTextColor(TXT2);
        pct.setPadding(0, dp(16), 0, dp(8));
        final ProgressBar bar = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgress(0);
        bar.setProgressTintList(ColorStateList.valueOf(ACCENT));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(DIVIDER));

        LinearLayout extra = new LinearLayout(a);
        extra.setOrientation(LinearLayout.VERTICAL);
        extra.addView(pct, new LinearLayout.LayoutParams(-1, -2));
        extra.addView(bar, new LinearLayout.LayoutParams(-1, dp(8)));

        Runnable doCancel = () -> { cancel = true; cleanUpdates(); };
        final Dialog dlg = dialog("Обновление", null, extra,
                new String[]{"Отмена"}, new Runnable[]{doCancel}, doCancel);
        dlg.show();

        Thread t = new Thread(() -> {
            boolean ok = false;
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(20000);
                int total = c.getContentLength();
                if (total <= 0) ui.post(() -> bar.setIndeterminate(true));
                try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(f)) {
                    byte[] buf = new byte[32768];
                    long done = 0;
                    int last = -1;
                    while (!cancel) {
                        int n = in.read(buf);
                        if (n < 0) { ok = true; break; }
                        out.write(buf, 0, n);
                        done += n;
                        if (total > 0) {
                            final int p = (int) Math.max(0, Math.min(100, done * 100 / total));
                            if (p != last) {
                                last = p;
                                ui.post(() -> { bar.setProgress(p); pct.setText("Загрузка обновления... " + p + "%"); });
                            }
                        }
                    }
                }
            } catch (Throwable e) { ok = false; }
            final boolean fin = ok;
            ui.post(() -> {
                if (cancel) { cleanUpdates(); return; }
                if (a.isFinishing()) return;
                dlg.dismiss();
                if (fin) install(f); else { cleanUpdates(); toast("Не удалось скачать обновление"); }
            });
        });
        t.setDaemon(true);
        t.start();
    }

    // ---------- установка поверх ----------
    private void install(File f) {
        try {
            Uri uri = FileProvider.getUriForFile(a, a.getPackageName() + ".fileprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            installPending = true;
            a.startActivity(i);
        } catch (SecurityException e) {
            installPending = false;
            cleanUpdates();
            askInstallPermission();
        } catch (Exception e) {
            installPending = false;
            cleanUpdates();
            toast("Не удалось запустить установщик");
        }
    }

    private void askInstallPermission() {
        dialog("Установка запрещена",
                "Разрешите установку из неизвестных источников для J.FTP в настройках, затем повторите проверку обновлений.",
                null, new String[]{"Открыть настройки", "Закрыть"},
                new Runnable[]{() -> {
                    try {
                        if (Build.VERSION.SDK_INT >= 26) a.startActivity(new Intent(
                                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName()))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        else a.startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e) { toast("Не удалось открыть настройки"); }
                }, () -> { }}, null).show();
    }

    // ---------- UI ----------

    /** Контейнер диалога: ширина <= 420dp, высота ограничена экраном с отступами. */
    private class Box extends LinearLayout {
        Box() { super(a); }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = Math.min(dp(MAX_W_DP), MeasureSpec.getSize(wSpec));
            int hs = MeasureSpec.getMode(hSpec) == MeasureSpec.UNSPECIFIED
                    ? Integer.MAX_VALUE : MeasureSpec.getSize(hSpec);
            int h = Math.min(hs, dm.heightPixels - dp(MARGIN_DP * 2));
            super.onMeasure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(h, MeasureSpec.AT_MOST));
        }
    }

    private Dialog dialog(String title, String msg, View extra, String[] names, Runnable[] acts, Runnable onCancel) {
        loadColors();
        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new Box();
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(24), dp(24), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16));
        bg.setColor(BG);
        bg.setStroke(dp(1), DIVIDER);
        box.setBackground(bg);

        // заголовок (фиксирован)
        TextView t = new TextView(a);
        t.setText(title);
        t.setTextSize(20);
        t.setTextColor(TXT);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        box.addView(t, new LinearLayout.LayoutParams(-1, -2));

        // контент (прокручивается)
        LinearLayout body = new LinearLayout(a);
        body.setOrientation(LinearLayout.VERTICAL);
        if (msg != null) {
            TextView m = new TextView(a);
            m.setText(msg);
            m.setTextSize(16);
            m.setTextColor(TXT2);
            m.setPadding(0, dp(8), 0, 0);
            body.addView(m, new LinearLayout.LayoutParams(-1, -2));
        }
        if (extra != null) body.addView(extra, new LinearLayout.LayoutParams(-1, -2));
        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(false);
        sv.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        sv.addView(body, new ViewGroup.LayoutParams(-1, -2));
        box.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        // кнопки (фиксированы внизу)
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        View first = null;
        for (int i = 0; i < names.length; i++) {
            final Runnable act = acts[i];
            boolean primary = names.length > 1 && i == 0;
            View b = button(names[i], primary, () -> { d.dismiss(); act.run(); });
            if (first == null) first = b;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) lp.leftMargin = dp(8);
            row.addView(b, lp);
        }
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(16);
        box.addView(row, rp);

        // обёртка с отступами от краёв экрана
        FrameLayout wrap = new FrameLayout(a);
        wrap.setPadding(dp(MARGIN_DP), dp(MARGIN_DP), dp(MARGIN_DP), dp(MARGIN_DP));
        wrap.addView(box, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        d.setContentView(wrap, new ViewGroup.LayoutParams(-1, -2));

        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        if (onCancel != null) d.setOnCancelListener(x -> onCancel.run());
        final View f = first;
        d.setOnShowListener(x -> { if (f != null) f.requestFocus(); });
        return d;
    }

    private TextView button(String text, boolean primary, Runnable onClick) {
        final TextView tv = new TextView(a);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setMinHeight(dp(48));
        tv.setPadding(dp(16), dp(8), dp(16), dp(8));
        tv.setFocusable(true);
        tv.setClickable(true);
        paint(tv, primary, false);
        tv.setOnFocusChangeListener((v, f) -> paint(tv, primary, f));
        tv.setOnClickListener(v -> onClick.run());
        return tv;
    }

    private void paint(TextView tv, boolean primary, boolean focused) {
        boolean filled = primary || focused;
        tv.setTextColor(filled ? ON_ACCENT : TXT);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(8));
        g.setColor(filled ? ACCENT : SURFACE_ALT);
        g.setStroke(dp(1), filled ? ACCENT : DIVIDER);
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(Color.WHITE);
        mask.setCornerRadius(dp(8));
        tv.setBackground(new RippleDrawable(ColorStateList.valueOf(RIPPLE), g, mask));
    }

    private int dp(int v) { return (int) (v * a.getResources().getDisplayMetrics().density); }

    private void toast(String s) { Toast.makeText(a, s, Toast.LENGTH_SHORT).show(); }

    private static String readAll(InputStream in) throws Exception {
        try (InputStream is = in; ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
            byte[] b = new byte[8192];
            int n;
            while ((n = is.read(b)) > 0) bo.write(b, 0, n);
            return bo.toString("UTF-8");
        }
    }
}
