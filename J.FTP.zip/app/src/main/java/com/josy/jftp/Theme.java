package com.josy.jftp;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.view.View;
import android.view.Window;

/** Выбор темы (светлая/тёмная) и доступ к цветовым токенам. Выбор хранится в SharedPreferences. */
public final class Theme {
    private static final String PREFS = "jftp_theme";
    private static final String K_LIGHT = "light";

    private static boolean light = false;
    private static boolean loaded = false;

    private Theme() { }

    public static synchronized void init(Context c) {
        if (loaded) return;
        light = c.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(K_LIGHT, false);
        loaded = true;
    }

    public static boolean isLight() { return light; }

    public static synchronized void toggle(Context c) {
        light = !light;
        loaded = true;
        c.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(K_LIGHT, light).apply();
    }

    private static int pick(Context c, int darkRes, int lightRes) {
        return c.getColor(light ? lightRes : darkRes);
    }

    public static int bg(Context c)         { return pick(c, R.color.dark_bg, R.color.light_bg); }
    public static int surface(Context c)    { return pick(c, R.color.dark_surface, R.color.light_surface); }
    public static int surfaceAlt(Context c) { return pick(c, R.color.dark_surface_alt, R.color.light_surface_alt); }
    public static int divider(Context c)    { return pick(c, R.color.dark_divider, R.color.light_divider); }
    public static int accent(Context c)     { return pick(c, R.color.dark_accent, R.color.light_accent); }
    public static int accentText(Context c) { return pick(c, R.color.dark_accent_text, R.color.light_accent_text); }
    public static int onAccent(Context c)   { return pick(c, R.color.dark_on_accent, R.color.light_on_accent); }
    public static int text(Context c)       { return pick(c, R.color.dark_text_primary, R.color.light_text_primary); }
    public static int text2(Context c)      { return pick(c, R.color.dark_text_secondary, R.color.light_text_secondary); }
    public static int error(Context c)      { return pick(c, R.color.dark_error, R.color.light_error); }
    public static int ripple(Context c)     { return pick(c, R.color.dark_ripple, R.color.light_ripple); }
    public static int rippleAccent(Context c) { return pick(c, R.color.dark_ripple_accent, R.color.light_ripple_accent); }

    /** Цвета статус-бара и навигации + тёмные/светлые иконки системных баров. */
    @SuppressWarnings("deprecation")
    public static void applySystemBars(Activity a) {
        Window w = a.getWindow();
        w.setStatusBarColor(bg(a));
        w.setNavigationBarColor(bg(a));
        View dv = w.getDecorView();
        int flags = dv.getSystemUiVisibility();
        int mask = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) mask |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        dv.setSystemUiVisibility(light ? (flags | mask) : (flags & ~mask));
    }
}
