package com.josy.jftp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;

import org.apache.ftpserver.FtpServer;
import org.apache.ftpserver.FtpServerFactory;
import org.apache.ftpserver.ftplet.Authority;
import org.apache.ftpserver.listener.ListenerFactory;
import org.apache.ftpserver.usermanager.impl.BaseUser;
import org.apache.ftpserver.usermanager.impl.WritePermission;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FtpService extends Service {
    public static final int DEFAULT_PORT = 2121;
    public static final String NO_NET = "нет Wi-Fi / сети";

    private static final String PREFS = "jftp_params";
    private static final String K_IP = "ip";
    private static final String K_USER = "user";
    private static final String K_PASS = "pass";
    private static final String K_PORT = "port";

    // Состояние, которое читает MainActivity
    public static volatile boolean running = false;
    public static volatile String ip = "";
    public static volatile String user = "";
    public static volatile String pass = "";
    public static volatile int port = DEFAULT_PORT;
    public static volatile String error = "";

    private FtpServer server;

    /**
     * Читает сохранённые параметры. Заполняет только отсутствующие значения
     * (первый запуск) и сохраняет их. Существующие значения не меняет никогда.
     */
    public static synchronized void ensureParams(Context c) {
        SharedPreferences sp = c.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        boolean dirty = false;

        String u = sp.getString(K_USER, "");
        if (u.isEmpty()) { u = "user"; e.putString(K_USER, u); dirty = true; }

        String p = sp.getString(K_PASS, "");
        if (p.isEmpty()) { p = newPassword(); e.putString(K_PASS, p); dirty = true; }

        int pt = sp.getInt(K_PORT, 0);
        if (pt <= 0) { pt = DEFAULT_PORT; e.putInt(K_PORT, pt); dirty = true; }

        String i = sp.getString(K_IP, "");
        if (i.isEmpty()) {
            String found = detectIp();
            if (found != null) { i = found; e.putString(K_IP, i); dirty = true; }
        }

        if (dirty) e.apply();
        user = u;
        pass = p;
        port = pt;
        ip = i.isEmpty() ? NO_NET : i;
    }

    /**
     * Единственный способ изменить параметры: вызывается кнопкой «Обновить».
     * IP определяется заново, пароль генерируется заново, логин и порт сохраняются.
     */
    public static synchronized void refreshParams(Context c) {
        ensureParams(c);
        SharedPreferences.Editor e = c.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        String found = detectIp();
        if (found != null) e.putString(K_IP, found);
        e.putString(K_PASS, newPassword());
        e.putString(K_USER, user);
        e.putInt(K_PORT, port);
        e.apply();
        ensureParams(c);
    }

    private static String newPassword() {
        return String.valueOf(100000 + new SecureRandom().nextInt(900000));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ensureParams(this);   // только чтение сохранённых значений
        error = "";
        startForegroundCompat();
        new Thread(this::startServer).start();
        return START_NOT_STICKY;
    }

    private void startServer() {
        try {
            BaseUser u = new BaseUser();
            u.setName(user);
            u.setPassword(pass);
            u.setHomeDirectory(Environment.getExternalStorageDirectory().getAbsolutePath());
            List<Authority> auth = new ArrayList<>();
            auth.add(new WritePermission());
            u.setAuthorities(auth);

            FtpServerFactory factory = new FtpServerFactory();
            ListenerFactory lf = new ListenerFactory();
            lf.setPort(port);
            factory.addListener("default", lf.createListener());
            factory.getUserManager().save(u);

            server = factory.createServer();
            server.start();
            running = true;
        } catch (Throwable t) {
            error = String.valueOf(t.getMessage());
            running = false;
            stopSelf();
        }
    }

    private void startForegroundCompat() {
        String channelId = "ftp";
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(
                    channelId, "FTP", NotificationManager.IMPORTANCE_LOW));
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, channelId)
                .setContentTitle("J.FTP: сервер работает")
                .setContentText("Порт " + port)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    /** IPv4 в локальной сети или null, если сети нет. */
    static String detectIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (server != null) {
            try { server.stop(); } catch (Throwable ignored) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
