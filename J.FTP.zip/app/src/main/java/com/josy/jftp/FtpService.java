package com.josy.jftp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;

import org.apache.ftpserver.FtpServer;
import org.apache.ftpserver.FtpServerFactory;
import org.apache.ftpserver.ftplet.Authority;
import org.apache.ftpserver.listener.ListenerFactory;
import org.apache.ftpserver.usermanager.impl.BaseUser;
import org.apache.ftpserver.usermanager.impl.WritePermission;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FtpService extends Service {
    public static final int PORT = 2121;
    public static final String EXTRA_USER = "user";
    public static final String EXTRA_PASS = "pass";

    // Состояние, которое читает MainActivity
    public static volatile boolean running = false;
    public static volatile String ip = "";
    public static volatile String user = "";
    public static volatile String pass = "";
    public static volatile String error = "";

    private FtpServer server;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        user = intent.getStringExtra(EXTRA_USER);
        pass = intent.getStringExtra(EXTRA_PASS);
        error = "";
        startForegroundCompat();
        new Thread(this::startServer).start();
        return START_NOT_STICKY;
    }

    private void startServer() {
        try {
            ip = findLocalIp();

            BaseUser u = new BaseUser();
            u.setName(user);
            u.setPassword(pass);
            u.setHomeDirectory(Environment.getExternalStorageDirectory().getAbsolutePath());
            List<Authority> auth = new ArrayList<>();
            auth.add(new WritePermission());
            u.setAuthorities(auth);

            FtpServerFactory factory = new FtpServerFactory();
            ListenerFactory lf = new ListenerFactory();
            lf.setPort(PORT);
            factory.addListener("default", lf.createListener());
            factory.getUserManager().save(u);

            server = factory.createServer();
            server.start();
            running = true;
        } catch (Throwable t) {
            error = String.valueOf(t.getMessage());
            running = false;
            stopSelf();
        }
    }

    private void startForegroundCompat() {
        String channelId = "ftp";
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(
                    channelId, "FTP", NotificationManager.IMPORTANCE_LOW));
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, channelId)
                .setContentTitle("J.FTP: сервер работает")
                .setContentText("Порт " + PORT)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    static String findLocalIp() throws Exception {
        for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!ni.isUp() || ni.isLoopback()) continue;
            for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                    return a.getHostAddress();
                }
            }
        }
        return "нет Wi-Fi / сети";
    }

    @Override
    public void onDestroy() {
        running = false;
        if (server != null) {
            try { server.stop(); } catch (Throwable ignored) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
