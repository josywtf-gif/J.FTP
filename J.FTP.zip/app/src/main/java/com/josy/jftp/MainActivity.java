package com.josy.jftp;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.security.SecureRandom;

public class MainActivity extends Activity {
    private Button button;
    private TextView info;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateUi();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        button = new Button(this);
        button.setTextSize(20);
        button.setOnClickListener(v -> toggle());
        root.addView(button, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (int) (72 * getResources().getDisplayMetrics().density)));

        info = new TextView(this);
        info.setTextSize(18);
        info.setTypeface(Typeface.MONOSPACE);
        info.setTextIsSelectable(true);
        info.setPadding(0, p, 0, 0);
        root.addView(info);

        setContentView(root);
    }

    @Override protected void onResume() { super.onResume(); handler.post(refresh); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(refresh); }

    private void toggle() {
        if (FtpService.running) {
            stopService(new Intent(this, FtpService.class));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (!hasStorageAccess()) return;

        String pass = String.valueOf(100000 + new SecureRandom().nextInt(900000));
        Intent i = new Intent(this, FtpService.class)
                .putExtra(FtpService.EXTRA_USER, "user")
                .putExtra(FtpService.EXTRA_PASS, pass);
        startForegroundService(i);
    }

    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (Environment.isExternalStorageManager()) return true;
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return false;
        }
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
            return false;
        }
        return true;
    }

    private void updateUi() {
        if (FtpService.running) {
            button.setText("Остановить");
            info.setText("ip:       " + FtpService.ip
                    + "\nport:     " + FtpService.PORT
                    + "\nname:     " + FtpService.user
                    + "\npassword: " + FtpService.pass
                    + "\n\nftp://" + FtpService.ip + ":" + FtpService.PORT);
        } else {
            button.setText("Запустить FTP");
            info.setText(FtpService.error.isEmpty() ? "" : "Ошибка: " + FtpService.error);
        }
    }
}
