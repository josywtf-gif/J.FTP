package com.josy.jftp;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private Button button;
    private Button refreshBtn;
    private LinearLayout card;
    private TextView info;
    private Updater updater;
    private float d;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateUi();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        updater = new Updater(this);
        updater.cleanUpdates();
        FtpService.ensureParams(this);   // первый запуск — заполнить один раз; дальше только чтение
        d = getResources().getDisplayMetrics().density;
        int p = dp(24);

        getWindow().setStatusBarColor(c(R.color.bg));
        getWindow().setNavigationBarColor(c(R.color.bg));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(c(R.color.bg));
        root.setPadding(p, p, p, p);
        root.setFitsSystemWindows(true);

        // центр: кнопка и данные сервера
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);

        button = new Button(this);
        button.setTextSize(20);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);
        button.setStateListAnimator(null);
        button.setOnClickListener(v -> toggle());
        center.addView(button, new LinearLayout.LayoutParams(-1, dp(72)));

        // блок данных сервера: текст + кнопка «Обновить»
        card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(p, p, p, p);
        card.setBackground(shape(c(R.color.surface), 16, c(R.color.divider)));
        card.setElevation(dp(2));
        card.setVisibility(View.GONE);

        info = new TextView(this);
        info.setTextSize(16);
        info.setTypeface(Typeface.MONOSPACE);
        info.setTextColor(c(R.color.text_primary));
        info.setHighlightColor(c(R.color.ripple_accent));
        info.setTextIsSelectable(true);
        card.addView(info, new LinearLayout.LayoutParams(-1, -2));

        refreshBtn = new Button(this);
        refreshBtn.setText("Обновить");
        refreshBtn.setTextSize(16);
        refreshBtn.setAllCaps(false);
        refreshBtn.setStateListAnimator(null);
        refreshBtn.setTextColor(c(R.color.text_primary));
        refreshBtn.setBackground(ripple(shape(c(R.color.surface_alt), 8, c(R.color.divider)), c(R.color.ripple), 8));
        refreshBtn.setOnClickListener(v -> refreshParams());
        LinearLayout.LayoutParams rb = new LinearLayout.LayoutParams(-1, dp(48));
        rb.topMargin = dp(8);
        card.addView(refreshBtn, rb);

        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(24);
        center.addView(card, ip);

        root.addView(center, new LinearLayout.LayoutParams(-1, 0, 1f));

        // низ: версия и кнопка обновления
        TextView ver = new TextView(this);
        ver.setText("J.FTP " + updater.versionName());
        ver.setGravity(Gravity.CENTER);
        ver.setTextSize(14);
        ver.setTextColor(c(R.color.text_secondary));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.bottomMargin = dp(8);
        root.addView(ver, vp);

        Button upd = new Button(this);
        upd.setText("Проверить обновления");
        upd.setTextSize(16);
        upd.setAllCaps(false);
        upd.setStateListAnimator(null);
        upd.setTextColor(c(R.color.text_primary));
        upd.setBackground(ripple(shape(c(R.color.surface_alt), 8, c(R.color.divider)), c(R.color.ripple), 8));
        upd.setOnClickListener(v -> updater.check());
        root.addView(upd, new LinearLayout.LayoutParams(-1, dp(56)));

        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        if (updater.installPending) {
            updater.installPending = false;
            handler.postDelayed(updater::cleanUpdates, 1000);
        }
        handler.post(refresh);
    }

    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(refresh); }

    private void toggle() {
        if (FtpService.running) {
            stopService(new Intent(this, FtpService.class));
            return;
        }
        startFtp();
    }

    private void startFtp() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (!hasStorageAccess()) return;
        startForegroundService(new Intent(this, FtpService.class));
    }

    // единственное место, где параметры меняются
    private void refreshParams() {
        FtpService.refreshParams(this);
        if (FtpService.running) {
            stopService(new Intent(this, FtpService.class));
            startFtp();   // перезапуск с обновлёнными значениями
        }
        updateUi();
    }

    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (Environment.isExternalStorageManager()) return true;
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return false;
        }
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
            return false;
        }
        return true;
    }

    private void updateUi() {
        if (FtpService.running) {
            styleButton(true);
            button.setText("Остановить");
            SpannableStringBuilder sb = new SpannableStringBuilder();
            row(sb, "ip:       ", FtpService.ip, true);
            row(sb, "port:     ", String.valueOf(FtpService.port), true);
            row(sb, "name:     ", FtpService.user, true);
            row(sb, "password: ", FtpService.pass, true);
            sb.append('\n');
            int s = sb.length();
            String url = "ftp://" + FtpService.ip + ":" + FtpService.port;
            sb.append(url);
            sb.setSpan(new ForegroundColorSpan(c(R.color.accent)), s, sb.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            info.setTextColor(c(R.color.text_primary));
            info.setText(sb);
            refreshBtn.setVisibility(View.VISIBLE);
            card.setVisibility(View.VISIBLE);
        } else {
            styleButton(false);
            button.setText("Запустить FTP");
            if (FtpService.error.isEmpty()) {
                info.setText("");
                card.setVisibility(View.GONE);
            } else {
                info.setTextColor(c(R.color.error));
                info.setText("Ошибка: " + FtpService.error);
                refreshBtn.setVisibility(View.GONE);
                card.setVisibility(View.VISIBLE);
            }
        }
    }

    private void row(SpannableStringBuilder sb, String label, String value, boolean nl) {
        int s = sb.length();
        sb.append(label);
        sb.setSpan(new ForegroundColorSpan(c(R.color.text_secondary)), s, sb.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.append(value);
        if (nl) sb.append('\n');
    }

    // запущен — контурная кнопка, остановлен — залитая акцентом
    private void styleButton(boolean running) {
        if (running) {
            button.setTextColor(c(R.color.accent));
            button.setBackground(ripple(shape(c(R.color.surface), 8, c(R.color.accent)), c(R.color.ripple_accent), 8));
        } else {
            button.setTextColor(c(R.color.on_accent));
            button.setBackground(ripple(shape(c(R.color.accent), 8, c(R.color.accent)), c(R.color.ripple), 8));
        }
        button.setElevation(dp(running ? 0 : 2));
    }

    // ---------- helpers ----------
    private int c(int res) { return getColor(res); }
    private int dp(int v) { return (int) (v * d); }

    private GradientDrawable shape(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private RippleDrawable ripple(GradientDrawable content, int color, int radiusDp) {
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(radiusDp));
        return new RippleDrawable(ColorStateList.valueOf(color), content, mask);
    }
}
