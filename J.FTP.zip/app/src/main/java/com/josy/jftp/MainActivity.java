package com.josy.jftp;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.security.SecureRandom;

public class MainActivity extends Activity {
    private Button button;
    private TextView info;
    private Updater updater;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateUi();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        updater = new Updater(this);
        updater.cleanUpdates();
        float d = getResources().getDisplayMetrics().density;
        int p = (int) (24 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, p, p, p);

        // центр: кнопка и данные сервера
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);

        button = new Button(this);
        button.setTextSize(20);
        button.setOnClickListener(v -> toggle());
        center.addView(button, new LinearLayout.LayoutParams(-1, (int) (72 * d)));

        info = new TextView(this);
        info.setTextSize(18);
        info.setTypeface(Typeface.MONOSPACE);
        info.setTextIsSelectable(true);
        info.setPadding(0, p, 0, 0);
        center.addView(info);

        root.addView(center, new LinearLayout.LayoutParams(-1, 0, 1f));

        // низ: версия и кнопка обновления
        TextView ver = new TextView(this);
        ver.setText("J.FTP " + updater.versionName());
        ver.setGravity(Gravity.CENTER);
        ver.setTextSize(14);
        ver.setAlpha(0.6f);
        root.addView(ver, new LinearLayout.LayoutParams(-1, -2));

        Button upd = new Button(this);
        upd.setText("Проверить обновления");
        upd.setOnClickListener(v -> updater.check());
        root.addView(upd, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        if (updater.installPending) {
            updater.installPending = false;
            handler.postDelayed(updater::cleanUpdates, 1000);
        }
        handler.post(refresh);
    }

    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(refresh); }

    private void toggle() {
        if (FtpService.running) {
            stopService(new Intent(this, FtpService.class));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (!hasStorageAccess()) return;

        String pass = String.valueOf(100000 + new SecureRandom().nextInt(900000));
        Intent i = new Intent(this, FtpService.class)
                .putExtra(FtpService.EXTRA_USER, "user")
                .putExtra(FtpService.EXTRA_PASS, pass);
        startForegroundService(i);
    }

    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (Environment.isExternalStorageManager()) return true;
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return false;
        }
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
            return false;
        }
        return true;
    }

    private void updateUi() {
        if (FtpService.running) {
            button.setText("Остановить");
            info.setText("ip:       " + FtpService.ip
                    + "\nport:     " + FtpService.PORT
                    + "\nname:     " + FtpService.user
                    + "\npassword: " + FtpService.pass
                    + "\n\nftp://" + FtpService.ip + ":" + FtpService.PORT);
        } else {
            button.setText("Запустить FTP");
            info.setText(FtpService.error.isEmpty() ? "" : "Ошибка: " + FtpService.error);
        }
    }
}
