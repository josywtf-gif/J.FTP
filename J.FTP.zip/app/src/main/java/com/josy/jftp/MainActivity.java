package com.josy.jftp;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private Button button;
    private Button refreshBtn;
    private LinearLayout card;
    private TextView info;
    private Updater updater;
    private float d;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateUi();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.init(this);   // сохранённая тема применяется при старте
        updater = new Updater(this);
        updater.cleanUpdates();
        FtpService.ensureParams(this);   // первый запуск — заполнить один раз; дальше только чтение
        d = getResources().getDisplayMetrics().density;
        buildUi();
    }

    /** Собирает экран заново в цветах текущей темы (используется и при старте, и при переключении). */
    private void buildUi() {
        Theme.applySystemBars(this);
        int p = dp(24);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.bg(this));
        root.setPadding(p, p, p, p);
        root.setFitsSystemWindows(true);

        // верх: заголовок + кнопка темы (справа)
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("J.FTP");
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Theme.text(this));
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        ImageButton themeBtn = new ImageButton(this);
        themeBtn.setImageResource(Theme.isLight() ? R.drawable.ic_moon : R.drawable.ic_sun);
        themeBtn.setImageTintList(ColorStateList.valueOf(Theme.text(this)));
        themeBtn.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        themeBtn.setPadding(dp(12), dp(12), dp(12), dp(12));
        themeBtn.setContentDescription(Theme.isLight() ? "Тёмная тема" : "Светлая тема");
        GradientDrawable mask = new GradientDrawable();
        mask.setShape(GradientDrawable.OVAL);
        mask.setColor(0xFFFFFFFF);
        themeBtn.setBackground(new RippleDrawable(ColorStateList.valueOf(Theme.ripple(this)), null, mask));
        themeBtn.setOnClickListener(v -> toggleTheme());
        header.addView(themeBtn, new LinearLayout.LayoutParams(dp(48), dp(48)));

        root.addView(header, new LinearLayout.LayoutParams(-1, dp(56)));

        // центр: кнопка и данные сервера
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);

        button = new Button(this);
        button.setTextSize(20);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);
        button.setStateListAnimator(null);
        button.setOnClickListener(v -> toggle());
        center.addView(button, new LinearLayout.LayoutParams(-1, dp(72)));

        // блок данных сервера: текст + кнопка «Обновить»
        card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(p, p, p, p);
        card.setBackground(shape(Theme.surface(this), 16, Theme.divider(this)));
        card.setElevation(dp(2));
        card.setVisibility(View.GONE);

        info = new TextView(this);
        info.setTextSize(16);
        info.setTypeface(Typeface.MONOSPACE);
        info.setTextColor(Theme.text(this));
        info.setHighlightColor(Theme.rippleAccent(this));
        info.setTextIsSelectable(true);
        card.addView(info, new LinearLayout.LayoutParams(-1, -2));

        refreshBtn = new Button(this);
        refreshBtn.setText("Обновить");
        refreshBtn.setTextSize(16);
        refreshBtn.setAllCaps(false);
        refreshBtn.setStateListAnimator(null);
        refreshBtn.setTextColor(Theme.text(this));
        refreshBtn.setBackground(ripple(shape(Theme.surfaceAlt(this), 8, Theme.divider(this)), Theme.ripple(this), 8));
        refreshBtn.setOnClickListener(v -> refreshParams());
        LinearLayout.LayoutParams rb = new LinearLayout.LayoutParams(-1, dp(48));
        rb.topMargin = dp(8);
        card.addView(refreshBtn, rb);

        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(24);
        center.addView(card, ip);

        root.addView(center, new LinearLayout.LayoutParams(-1, 0, 1f));

        // низ: версия и кнопка обновления
        TextView ver = new TextView(this);
        ver.setText("J.FTP " + updater.versionName());
        ver.setGravity(Gravity.CENTER);
        ver.setTextSize(14);
        ver.setTextColor(Theme.text2(this));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.bottomMargin = dp(8);
        root.addView(ver, vp);

        Button upd = new Button(this);
        upd.setText("Проверить обновления");
        upd.setTextSize(16);
        upd.setAllCaps(false);
        upd.setStateListAnimator(null);
        upd.setTextColor(Theme.text(this));
        upd.setBackground(ripple(shape(Theme.surfaceAlt(this), 8, Theme.divider(this)), Theme.ripple(this), 8));
        upd.setOnClickListener(v -> updater.check());
        root.addView(upd, new LinearLayout.LayoutParams(-1, dp(56)));

        setContentView(root);
    }

    private void toggleTheme() {
        Theme.toggle(this);
        buildUi();
        updateUi();
    }

    @Override protected void onResume() {
        super.onResume();
        if (updater.installPending) {
            updater.installPending = false;
            handler.postDelayed(updater::cleanUpdates, 1000);
        }
        handler.post(refresh);
    }

    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(refresh); }

    private void toggle() {
        if (FtpService.running) {
            stopService(new Intent(this, FtpService.class));
            return;
        }
        startFtp();
    }

    private void startFtp() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (!hasStorageAccess()) return;
        startForegroundService(new Intent(this, FtpService.class));
    }

    // единственное место, где параметры меняются
    private void refreshParams() {
        FtpService.refreshParams(this);
        if (FtpService.running) {
            stopService(new Intent(this, FtpService.class));
            startFtp();   // перезапуск с обновлёнными значениями
        }
        updateUi();
    }

    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (Environment.isExternalStorageManager()) return true;
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return false;
        }
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
            return false;
        }
        return true;
    }

    private void updateUi() {
        if (FtpService.running) {
            styleButton(true);
            button.setText("Остановить");
            SpannableStringBuilder sb = new SpannableStringBuilder();
            row(sb, "ip:       ", FtpService.ip, true);
            row(sb, "port:     ", String.valueOf(FtpService.port), true);
            row(sb, "name:     ", FtpService.user, true);
            row(sb, "password: ", FtpService.pass, true);
            sb.append('\n');
            int s = sb.length();
            String url = "ftp://" + FtpService.ip + ":" + FtpService.port;
            sb.append(url);
            sb.setSpan(new ForegroundColorSpan(Theme.accentText(this)), s, sb.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            info.setTextColor(Theme.text(this));
            info.setText(sb);
            refreshBtn.setVisibility(View.VISIBLE);
            card.setVisibility(View.VISIBLE);
        } else {
            styleButton(false);
            button.setText("Запустить FTP");
            if (FtpService.error.isEmpty()) {
                info.setText("");
                card.setVisibility(View.GONE);
            } else {
                info.setTextColor(Theme.error(this));
                info.setText("Ошибка: " + FtpService.error);
                refreshBtn.setVisibility(View.GONE);
                card.setVisibility(View.VISIBLE);
            }
        }
    }

    private void row(SpannableStringBuilder sb, String label, String value, boolean nl) {
        int s = sb.length();
        sb.append(label);
        sb.setSpan(new ForegroundColorSpan(Theme.text2(this)), s, sb.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.append(value);
        if (nl) sb.append('\n');
    }

    // запущен — контурная кнопка, остановлен — залитая акцентом
    private void styleButton(boolean running) {
        if (running) {
            button.setTextColor(Theme.accentText(this));
            button.setBackground(ripple(shape(Theme.surface(this), 8, Theme.accent(this)), Theme.rippleAccent(this), 8));
        } else {
            button.setTextColor(Theme.onAccent(this));
            button.setBackground(ripple(shape(Theme.accent(this), 8, Theme.accent(this)), Theme.ripple(this), 8));
        }
        button.setElevation(dp(running ? 0 : 2));
    }

    // ---------- helpers ----------
    private int dp(int v) { return (int) (v * d); }

    private GradientDrawable shape(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private RippleDrawable ripple(GradientDrawable content, int color, int radiusDp) {
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(radiusDp));
        return new RippleDrawable(ColorStateList.valueOf(color), content, mask);
    }
}
