# J.FTP

Одна кнопка — локальный FTP-сервер на Android. Показывает ip, port, name и password.

Сборка: GitHub → Actions → Build APK → Artifacts → `J.FTP-debug`.
