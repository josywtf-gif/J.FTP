# J.FTP

Одна кнопка — локальный FTP-сервер на Android. Показывает ip, port, name и password.
Кнопка «Проверить обновления» скачивает новую версию из GitHub Releases и ставит поверх текущей.

Сборка: загрузить zip в репозиторий → GitHub Actions соберёт APK и опубликует релиз.
Не менять: applicationId `com.josy.jftp` и файл `app/jftp.keystore` (иначе обновление не встанет поверх).
